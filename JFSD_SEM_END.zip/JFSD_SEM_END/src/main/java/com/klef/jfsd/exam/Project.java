package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class Project 
{
    public static void main( String[] args )
    {
      try {
        System.out.println("Hello Hibernate");
        Configuration cfg = new Configuration();
        cfg.configure();
        SessionFactory sf = cfg.buildSessionFactory();
        Session s = sf.openSession();

        // Insert Data
        Transaction tnx = s.beginTransaction();
        ClientDemo sd = new ClientDemo();
        sd.setSid(6);
        sd.setSname("Ibraheem");
        sd.setEmailid("skibrahimkhalillullah@gmail.com");
        sd.setFee(130000);
        s.save(sd); 
        tnx.commit();
        System.out.println("Data Inserted");

        // Retrieve Data
        ClientDemo sd1 = s.find(ClientDemo.class, 2);
        System.out.println(sd1);
        System.out.println("Data Retrieved");

        // Update Data
        ClientDemo sd2 = s.find(ClientDemo.class, 2);
        if (sd2 != null) {
            sd2.setSname("Ibraheem");
            s.merge(sd2);
            Transaction tnx1 = s.beginTransaction();
            tnx1.commit();
            System.out.println("Data Updated");
        } else {
            System.out.println("Student with ID 2 not found for update.");
        }

        // Delete Data
        ClientDemo sd4 = s.find(ClientDemo.class, 4);
        if (sd4 != null) {
            Transaction tnx2 = s.beginTransaction();
            s.remove(sd4);
            tnx2.commit();
            System.out.println("Data Deleted");
        } else {
            System.out.println("Student with ID 2 not found for deletion.");
        }

        s.close();
      } catch(Exception e) {
        e.printStackTrace();
      }
    }
}